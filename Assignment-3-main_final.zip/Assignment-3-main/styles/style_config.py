BUTTON_STYLE = {
    'width': 20,
    'padding': 10
}

CANVAS_STYLE = {
    'background': 'grey',
    'width': 600,
    'height': 600
}
